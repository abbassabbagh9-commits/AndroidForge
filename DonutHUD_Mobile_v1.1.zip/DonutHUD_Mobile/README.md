# Donut HUD 1.1 — Android project

A small fixed top-left Android floating overlay. The arrow/distance guide works from coordinates the user manually enters for a destination they own or are authorized to monitor.

## Important
- This is source code, not a compiled APK.
- It does not connect to Donut SMP or Minecraft.
- It cannot read live player coordinates, admin status, FPS, ping, or discover hidden bases.
- Update your current X/Y/Z manually in the app as you move.
- The arrow is a simple cardinal-direction indicator, not a live game compass.

## Build on Android
Open the project in an Android IDE/build environment that supports Gradle Android projects, sync, then build an APK. Grant "Display over other apps" permission and tap Start Floating HUD.
