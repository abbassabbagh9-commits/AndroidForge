package com.carter.donuthud

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.sqrt

class HudService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        val channel = "donut_hud"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channel, "Donut HUD", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel)
            else @Suppress("DEPRECATION") Notification.Builder(this)
        notification.setContentTitle("Donut HUD running")
            .setContentText("Compact coordinate guide is active")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
        startForeground(9, notification.build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        render()
    }

    private fun render() {
        val p = getSharedPreferences("coords", MODE_PRIVATE)
        fun num(k: String): Double? = p.getString(k, "")?.toDoubleOrNull()
        val cx = num("cx"); val cy = num("cy"); val cz = num("cz")
        val tx = num("tx"); val ty = num("ty"); val tz = num("tz")
        val dx = if (cx != null && tx != null) tx - cx else null
        val dz = if (cz != null && tz != null) tz - cz else null
        val distance = if (dx != null && dz != null) sqrt(dx*dx + dz*dz) else null
        val arrow = if (dx != null && dz != null) {
            when {
                kotlin.math.abs(dx) > kotlin.math.abs(dz) && dx > 0 -> "→"
                kotlin.math.abs(dx) > kotlin.math.abs(dz) -> "←"
                dz > 0 -> "↓"
                else -> "↑"
            }
        } else "•"
        val panelView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(9, 7, 9, 7)
            setBackgroundColor(Color.rgb(28, 7, 7))
        }
        fun addLine(s: String, size: Float, color: Int) {
            panelView.addView(TextView(this).apply {
                text = s
                textSize = size
                setTextColor(color)
            })
        }
        addLine("DONUT HUD", 11f, Color.rgb(255, 65, 65))
        addLine("$arrow  ${distance?.let { "DIST ${"%.1f".format(it)}m" } ?: "SET COORDS"}", 10f, Color.WHITE)
        addLine("X ${cx?.toInt() ?: "--"} Y ${cy?.toInt() ?: "--"} Z ${cz?.toInt() ?: "--"}", 9f, Color.LTGRAY)
        addLine("DEST ${tx?.toInt() ?: "--"}, ${tz?.toInt() ?: "--"}", 9f, Color.LTGRAY)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 8
            y = 75
        }
        wm.addView(panelView, params)
        panel = panelView
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
