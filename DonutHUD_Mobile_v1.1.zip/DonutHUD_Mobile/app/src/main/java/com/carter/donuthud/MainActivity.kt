package com.carter.donuthud

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var currentX: EditText
    private lateinit var currentY: EditText
    private lateinit var currentZ: EditText
    private lateinit var targetX: EditText
    private lateinit var targetY: EditText
    private lateinit var targetZ: EditText

    private fun field(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or
            android.text.InputType.TYPE_NUMBER_FLAG_SIGNED or
            android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setSingleLine(true)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.LTGRAY)
        setPadding(12, 8, 12, 8)
        setBackgroundColor(Color.rgb(35, 35, 35))
    }

    private fun row(label: String, a: EditText, b: EditText, c: EditText): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(this).apply {
            text = label
            setTextColor(Color.rgb(255, 90, 90))
            textSize = 14f
        })
        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(a, b, c).forEachIndexed { i, e ->
            e.hint = listOf("X", "Y", "Z")[i]
            fields.addView(e, LinearLayout.LayoutParams(0, 54, 1f).apply {
                setMargins(3, 4, 3, 4)
            })
        }
        box.addView(fields)
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("coords", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(Color.rgb(12, 12, 12))
        }
        root.addView(TextView(this).apply {
            text = "DONUT HUD"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 65, 65))
        })
        root.addView(TextView(this).apply {
            text = "Compact left-corner coordinate guide"
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        })
        currentX = field("X"); currentY = field("Y"); currentZ = field("Z")
        targetX = field("X"); targetY = field("Y"); targetZ = field("Z")
        currentX.setText(prefs.getString("cx", "")); currentY.setText(prefs.getString("cy", ""))
        currentZ.setText(prefs.getString("cz", "")); targetX.setText(prefs.getString("tx", ""))
        targetY.setText(prefs.getString("ty", "")); targetZ.setText(prefs.getString("tz", ""))
        root.addView(row("YOUR CURRENT COORDINATES (enter manually)", currentX, currentY, currentZ))
        root.addView(row("SAVED DESTINATION (your/authorized location)", targetX, targetY, targetZ))
        root.addView(TextView(this).apply {
            text = "The app cannot read Minecraft coordinates or discover hidden bases. Update your current coordinates manually as you move."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 12, 0, 12)
        })
        root.addView(Button(this).apply {
            text = "SAVE COORDINATES"
            setOnClickListener {
                prefs.edit()
                    .putString("cx", currentX.text.toString()).putString("cy", currentY.text.toString())
                    .putString("cz", currentZ.text.toString()).putString("tx", targetX.text.toString())
                    .putString("ty", targetY.text.toString()).putString("tz", targetZ.text.toString()).apply()
                Toast.makeText(this@MainActivity, "Coordinates saved", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "GRANT OVERLAY PERMISSION"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permission already granted", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "START FLOATING HUD"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, HudService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        root.addView(Button(this).apply {
            text = "STOP FLOATING HUD"
            setOnClickListener { stopService(Intent(this@MainActivity, HudService::class.java)) }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
